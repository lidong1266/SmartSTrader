nosetests -A "not slow and not network" pandas --processes=4 $*
