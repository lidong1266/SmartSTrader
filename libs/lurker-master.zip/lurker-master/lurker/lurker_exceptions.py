# -*- coding: utf-8 -*-


class LurkerInvalidConfigurationObjectException(Exception):
    pass


class LurkerNoConnectivityException(Exception):
    pass


class MultipleResultsFoundException(Exception):
    pass
