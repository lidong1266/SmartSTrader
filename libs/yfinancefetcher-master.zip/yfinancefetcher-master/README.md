YFinanceFetcher
===============

A Python class to extract current and historical stock data from famous Yahoo Finance API.

Further information of its usage, in the wiki:
https://github.com/figurebelow/yfinancefetcher/wiki/YFinanceFetcher-how-to

Disclaimer:
this module provides access to a non-official Yahoo API. In fact they do not provide any type of support/documentation
of it and all existent information has been obtained through reverse engineering along the years. <br>
However it is a well-known API in the finance world.<br>
Real-time data is not guaranteed to be so real, rest of the values usually are delayed.<br>
Use at your own risk and do not abuse Yahoo resources.
